package de.Amazon.TestBase;



import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class TestBase {
	
	public static WebDriver driver;
	public static Properties prop;
	
	//Read the config property file
	public TestBase()
	{
		prop= new Properties();
		FileInputStream ip;
		try {
			ip = new FileInputStream(System.getProperty("user.dir")+"/src/config/config.properties");
			prop.load(ip);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	//All generic functions are capture in this method such as launching browser, implicit wait, url etc
	public void initalization() throws InterruptedException
	{
        String browserName = prop.getProperty("browser");
		
		if(browserName.equals("chrome")){
		System.setProperty("webdriver.chrome.driver","D:\\simpleTestUnzer\\AmazonTestAutomation\\Browser\\chromedriver.exe");
		driver = new ChromeDriver(); 
		}
		else if(browserName.equals("FF")){
				
			driver = new FirefoxDriver(); 
		}
		
		driver.get(prop.getProperty("url"));
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);

	}	

}
