package de.Amazon.TestCases;


import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import de.Amazon.Pages.TestPage;
import de.Amazon.TestBase.TestBase;

public class TestCase_0001 extends TestBase{
	
  
	TestPage tp=new TestPage();


	@BeforeMethod
	public void setUp() throws InterruptedException
	{
		initalization();
	}
	
	
	@Test
	public void paymentValidation() throws InterruptedException
	{  
		
		tp.testflow();

	}
	
	@AfterMethod
	public void tearDown()
	{
		driver.quit();
	}
	
	

}
