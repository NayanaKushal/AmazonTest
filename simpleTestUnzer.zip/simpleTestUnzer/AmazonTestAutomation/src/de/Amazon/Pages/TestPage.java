package de.Amazon.Pages;



import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import de.Amazon.TestBase.TestBase;

public class TestPage extends TestBase{
	
	public void testflow() throws InterruptedException
{
		
		
		//search any item
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys("Apple iPhone 12 mini",Keys.ENTER);
		
		Thread.sleep(1000);
		
		//Click on item
		driver.findElement(By.xpath("//*[@id=\"search\"]/div[1]/div[1]/div/span[3]/div[2]/div[2]/div/span/div/div/div/div/div[2]/div[1]/div/div/span/a/div/img")).click();
		
		
		//Scroll down 
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("window.scrollBy(0,1000)");
		
		
		
		//Click on quantity
		Select quantity = new Select(driver.findElement(By.id("quantity")));
		quantity.selectByIndex(1);
		
		//Click on Add to basket
		driver.findElement(By.xpath("//*[@id=\"add-to-cart-button\"]")).click();
		
		Thread.sleep(1000);
		
		// click on No Thanks
	    driver.findElement(By.xpath("//*[@id=\"attachSiNoCoverage\"]/span/input")).click();
	    
	    //Click on proceed to checkout
	    driver.findElement(By.xpath("//*[@id=\"attach-sidesheet-checkout-button\"]/span/input")).click();
	    
	    //Enter email or phone number
	    driver.findElement(By.id("ap_email")).sendKeys("+491630284767");
	    
	    //Click on continue
	    driver.findElement(By.id("continue")).click();
	    
	    //Enter password
	    driver.findElement(By.id("ap_password")).sendKeys("password");
	    
	    //Click on sign
	    driver.findElement(By.id("signInSubmit")).click();
	    
	 
	    //Scroll down
	    JavascriptExecutor jse1= (JavascriptExecutor)driver;
		jse1.executeScript("window.scrollBy(0,350)");

		//Click on gift card link
		driver.findElement(By.xpath(".//span[text()='Enter a gift card, voucher or promotional code']")).click();
		
		//Enter the invalid coupon code
		driver.findElement(By.name("ppw-claimCode")).sendKeys("000", Keys.TAB);
		
		//click on Apply button without entering the value
		driver.findElement(By.name("ppw-claimCodeApplyPressed")).click();
		
		
		//Capture the warning message
		String actual_message=driver.findElement(By.xpath("//div[@id='checkoutDisplayPage']//following::li/span[text()='The promotional code you entered is not valid']")).getText();
		System.out.println("Actual message displayed is" +actual_message);
		String expected_message= "The promotional code you entered is not valid";
		Assert.assertEquals(actual_message, expected_message);
		
		System.out.println("Test scenario is Completed");
	  		
}

}